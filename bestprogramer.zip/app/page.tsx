"use client"

import  from "../webpack.config"

export default function SyntheticV0PageForDeployment() {
  return < />
}