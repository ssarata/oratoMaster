package com.bestprogramer.bestprogramer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BestprogramerApplicationTests {

	@Test
	void contextLoads() {
	}

}
