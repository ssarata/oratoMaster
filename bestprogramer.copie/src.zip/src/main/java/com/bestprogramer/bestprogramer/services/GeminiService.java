package com.bestprogramer.bestprogramer.services;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class GeminiService {

    // Injection des configurations depuis application.properties
    @Value("${gemini.api.key}")
    private String apiKey; // Clé API pour l'authentification

    @Value("${gemini.api.url}")
    private String apiUrl; // URL de base de l'API Gemini

    // Client HTTP pour les requêtes REST
    private final RestTemplate restTemplate = new RestTemplate();

    /**
     * Méthode pour générer du contenu via l'API Gemini
     * @param prompt Le texte d'entrée pour la génération
     * @return La réponse textuelle de l'API
     */
    public String generateContent(String prompt) {
        // ====== 1. Construction du corps de la requête ======
        Map<String, Object> requestBody = new HashMap<>();
        
        // Structure des contenus attendue par l'API
        List<Map<String, Object>> contents = new ArrayList<>();
        Map<String, Object> part = new HashMap<>();
        part.put("text", prompt); // Le prompt utilisateur
        
        Map<String, Object> content = new HashMap<>();
        content.put("parts", List.of(part)); // Les parties du contenu
        contents.add(content); // Ajout au tableau de contenus
        
        requestBody.put("contents", contents); // Finalisation du corps

        // ====== 2. Configuration des en-têtes HTTP ======
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON); // Type de contenu JSON

        // ====== 3. Construction de la requête complète ======
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

        // ====== 4. Appel à l'API Gemini ======
        ResponseEntity<Map> response = restTemplate.postForEntity(
                apiUrl + "?key=" + apiKey, // URL avec paramètre d'API key
                request, // Corps + headers
                Map.class // Type de réponse attendue (JSON désérialisé en Map)
        );

        // ====== 5. Traitement de la réponse ======
        if (response.getStatusCode() == HttpStatus.OK) {
            Map<String, Object> body = response.getBody();
            
            // Vérification de la structure de réponse
            if (body != null && body.containsKey("candidates")) {
                List<Map<String, Object>> candidates = (List<Map<String, Object>>) body.get("candidates");
                
                if (!candidates.isEmpty()) {
                    // Extraction du premier candidat
                    Map<String, Object> candidate = candidates.get(0);
                    Map<String, Object> contentMap = (Map<String, Object>) candidate.get("content");
                    
                    // Extraction des parties textuelles
                    List<Map<String, Object>> parts = (List<Map<String, Object>>) contentMap.get("parts");
                    return (String) parts.get(0).get("text"); // Retourne le texte généré
                }
            }
        }
        
        // Retour par défaut en cas d'erreur
        return "Erreur : Aucune réponse valide de l'API Gemini";
    }
}