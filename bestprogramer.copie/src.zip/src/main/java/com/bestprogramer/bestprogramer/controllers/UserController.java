package com.bestprogramer.bestprogramer.controllers;

import com.bestprogramer.bestprogramer.models.User;
import com.bestprogramer.bestprogramer.repositories.UserRepository;
import com.bestprogramer.bestprogramer.services.FileStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Controller
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private FileStorageService fileStorageService;

    @GetMapping
    public String listusers(Model model) {
        model.addAttribute("users", userRepository.findByRole("apprenant"));
        // model.addAttribute("users", users);
        model.addAttribute("user", new User());

        return "users/index";
    }

    

    @PostMapping("/create")
    public String saveUser(@ModelAttribute User user,
        @RequestParam("photoFile") MultipartFile photoFile//,
        ) throws IOException {

        if (!photoFile.isEmpty()) {
        user.setPhoto(fileStorageService.storeFile(photoFile));
        }
       

        user.setRole("apprenant");
        userRepository.save(user);
        return "redirect:/users";
        }

   
    @PostMapping("/update/{id}")
    public String updateUser(@PathVariable Long id,
                             @ModelAttribute User user,
                             @RequestParam("photoFile") MultipartFile photoFile) throws IOException {

        User existing = userRepository.findById(id).orElseThrow();

        existing.setNom(user.getNom());
        existing.setPrenom(user.getPrenom());
        existing.setEmail(user.getEmail());
        existing.setMotDePasse(user.getMotDePasse());
        existing.setSexe(user.getSexe());
        existing.setContact(user.getContact());
        existing.setRole("apprenant");

        if (!photoFile.isEmpty()) {
            existing.setPhoto(fileStorageService.storeFile(photoFile));
        }
     

        userRepository.save(existing);
        return "redirect:/users";
    }

    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userRepository.deleteById(id);
        return "redirect:/users";
    }
}
