package com.bestprogramer.bestprogramer.models;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    
    private String nom;

    @Column(nullable = false)
    private String prenom;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String motDePasse;

    @Column(nullable = true)
    private String sexe;

    @Column(nullable = true)
    private String contact;

    @Column(nullable = true)
    private String cv;

    @Column(nullable = true)
    private String role; // "formateur" ou "apprenant"

    @Column(nullable = true)
    private String photo;

    public void setFilePath(String originalFilename) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setFilePath'");
    }
}
