package com.bestprogramer.bestprogramer.controllers;

import com.bestprogramer.bestprogramer.services.GeminiService;
import com.bestprogramer.bestprogramer.services.PdfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;


@Controller
public class GeminiController {

    @Autowired
    private GeminiService geminiService;

    @Autowired
    private PdfService pdfService;

    
   
    
    public GeminiController(GeminiService geminiService, PdfService pdfService) {
        this.geminiService = geminiService;
        this.pdfService = pdfService;
    }

    @GetMapping("/listecours")
    public ResponseEntity<byte[]> generateCoursePdf() throws IOException {
        String prompt = "Écris un cours complet d'art oratoire structuré  et bien detaillés en chapitres et sections.";
        String courseContent = geminiService.generateContent(prompt);
        
        ByteArrayOutputStream pdfStream = pdfService.generateCoursePdf(courseContent);
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDisposition(
            ContentDisposition.builder("attachment")
                .filename("cours_art_oratoire.pdf")
                .build());
        
        return new ResponseEntity<>(pdfStream.toByteArray(), headers, HttpStatus.OK);
    }
}

    